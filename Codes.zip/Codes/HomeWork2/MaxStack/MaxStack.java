
/*Java program to implement max function which returns the maximum value in the stack*/
import java.util.Stack;

public class MaxStack {
	Stack<Integer> stack = new Stack<Integer>();
	Stack<Integer> maxs = new Stack<Integer>();;

	/* push function pushes the value in the stack */
	public void push(int number) {
		stack.push(number);
		if (maxs.empty()) {
			maxs.push(number);
		} else {
			/*
			 * if the current maximum number is less than the input - push the value in the
			 * max stack
			 */
			if (maxs.peek() < number) {
				maxs.push(number);
			}
		}
	}

	/* pop function pops the value from the stack */
	public void pop() {
		if (stack.peek() == maxs.peek()) {
			maxs.pop();
		}
		System.out.println("Popped value is " + stack.pop());

	}

	/* max function displays the maximum number in the stack */
	public void max() {
		System.out.println("maximum number of the stack is " + maxs.peek());
	}
}
