/*Main function to demonstrate the max function*/

public class StackDemo {

	public static void main(String[] args) {
		MaxStack maxm = new MaxStack();
		maxm.push(1);
		maxm.push(2);
		maxm.push(3);
		maxm.push(7);
		maxm.push(5);
		maxm.max();
		maxm.push(11);
		maxm.max();
		maxm.pop();
		maxm.max();

	}

}
