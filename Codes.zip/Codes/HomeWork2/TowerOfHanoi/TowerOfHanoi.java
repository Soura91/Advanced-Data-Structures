
/*Java Program to implement Tower of Hanoi using Stacks*/
import java.util.Scanner;
import java.util.Stack;

public class TowerOfHanoi {
	public static Stack<Integer> tower[] = new Stack[4];

	/* function tow stores all the disks in tower 1 */
	public static void tow(int n) {
		for (int i = n; i > 0; i--) {
			tower[1].push(i);
		}
		move(n, 1, 3, 2);
	}

	/* move function moves the disks from peg 1 to peg 3 recursively */
	public static void move(int n, int fromPeg, int toPeg, int tempPeg) {
		if (n > 0) {
			move(n - 1, fromPeg, tempPeg, toPeg);
			int val = tower[fromPeg].pop();
			tower[toPeg].push(val);
			display(val, fromPeg, toPeg);
			move(n - 1, tempPeg, toPeg, fromPeg);
		}
	}

	/* display function displays the movement of disks */
	public static void display(int n, int source, int dest) {
		System.out.println("Disk " + n + " is moved from  Peg " + source + " to Peg " + dest);
	}

	/* main function to demonstrate tower of Hanoi */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number of discs");
		int n = input.nextInt();
		tower[1] = new Stack<Integer>();
		tower[2] = new Stack<Integer>();
		tower[3] = new Stack<Integer>();
		tow(n);
	}
}
