/* Course Schedule – Topology Sort */

import java.util.*;

public class topobfs {

	public static boolean canFinish(int numCourses, int[][] prerequisites) {

		if (numCourses == 0 || numCourses == 1)
			return true; /* no course or one course means no pre-requisite */
		if (prerequisites == null || prerequisites.length == 0)
			return true; /* means no pre-requisite */

		int len = prerequisites.length;

		/* Adjacency matrix representation of the graph */
		Map<Integer, List<Integer>> graph = new HashMap<>();

		int[] indegree = new int[numCourses];

		for (int i = 0; i < len; i++) {
			int from = prerequisites[i][1];
			int to = prerequisites[i][0];

			indegree[to]++;

			/* Formation of Graph */
			List<Integer> adjacents = graph.getOrDefault(from, new ArrayList<>());
			adjacents.add(to);
			graph.put(from, adjacents);
		}

		Queue<Integer> queue = new LinkedList<>();
		for (int i = 0; i < numCourses; i++) {
			if (indegree[i] == 0)
				queue.offer(i);
		}

		Set<Integer> visited = new HashSet<>();

		/* Using BFS */
		while (!queue.isEmpty()) {
			/* graph nodes forming cycle will not be added to the queue */
			int e = queue.poll();
			visited.add(e);

			/* Remove incoming edges and add only adjacent into the queue which have in-degree as 0*/
			for (int adj : graph.getOrDefault(e, new ArrayList<>())) {
				if (!visited.contains(adj)) {
					indegree[adj]--;
					if (indegree[adj] == 0)
						queue.offer(adj);
				}
			}
		}
		return visited.size() == numCourses; /* check if all courses are visited */
	}

	public static void main(String[] args) {

		int[][] p = { { 1, 0 } };
		int[][] q = { { 1, 0 }, { 0, 1 } };

		System.out.println(canFinish(2, p));
		System.out.println(canFinish(2, q));

	}

}
