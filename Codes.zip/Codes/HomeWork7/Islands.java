import java.util.Scanner;

public class Islands {

	public static int numIslands(char[][] grid) {
		if (grid.length == 0)
			return 0;
		int m = grid.length, n = grid[0].length;
		int count = 0;
		for (int i = 0; i < m; i++)
			for (int j = 0; j < n; j++)
				if (grid[i][j] == 'L') {
					count++;
					dfs(grid, i, j);
				}
		return count;

	}

	public static void dfs(char[][] grid, int i, int j) {

		if (i < 0 || i >= grid.length || j < 0 || j >= grid[i].length || grid[i][j] == 'W' || grid[i][j] == '#')
			return;
		grid[i][j] = '#';
		dfs(grid, i + 1, j);
		dfs(grid, i - 1, j);
		dfs(grid, i, j + 1);
		dfs(grid, i, j - 1);
	}

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
        System.out.println("Enter the rows and columns");
        int rows = scan.nextInt();
        int cols = scan.nextInt();
        System.out.println("Enter the values");
        char[][] grid=new char[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                grid[i][j] = scan.next().charAt(0);
            }
        }
        System.out.println("Array is:\n");
        for (int i = 0; i < rows; i++) {
        String s = "";
            for (int j = 0; j < cols; j++) {
             s += grid[i][j] + " ";
            }
            System.out.println(s);
        }
        scan.close();
       System.out.println("\nMinimum number number of island is " + numIslands(grid));
	}

}