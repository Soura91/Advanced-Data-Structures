/* Main Function to demonstrate the queue */
public class CirQueueDemo {

	public static void main(String[] args) {
		CirQueue s = new CirQueue(5);
		System.out.println(s.empty());
		s.enqueue(1);
		s.enqueue(2);
		s.enqueue(3);
		s.enqueue(4);
		s.enqueue(5);
		System.out.println(s.dequeue());
		System.out.println(s.dequeue());
		System.out.println(s.peek());
		s.enqueue(10);
		s.enqueue(11);
		System.out.println(s.peek());
		System.out.println(s.dequeue());
		System.out.println(s.dequeue());
		System.out.println(s.peek());
		System.out.println(s.dequeue());
		System.out.println(s.peek());
		System.out.println(s.dequeue());
		System.out.println(s.dequeue());
	}

}
