/* Java program to implement queue using Array()-- Circular Queue */
public class CirQueue {
	private int[] q;
	private int rear;
	private int front;
	private int ASIZE = 0; /* Array Size */

	public CirQueue(int s) {
		q = new int[s];
		rear = 0;
		front = 0;
		ASIZE = s;
	}

	/* enqueue function adds the data into the queue */
	public void enqueue(int data) {
		/* Queue is full */
		if ((rear + 1) % ASIZE == front) {
			System.out.println("The Queue is full");
		} else {
			q[rear] = data;
			rear = ((rear + 1) % ASIZE);
		}
		// If at end of array, wrap around
		if (rear == q.length)
			rear = 0;
	}

	/* empty function checks if the queue is empty */
	public boolean empty() {
		if (front == rear)
			return true;
		else
			return false;
	}

	/* dequeue function removes the element from the queue */
	public int dequeue() {
		int value = 0;
		if (empty()) {
			System.out.println("Queue is empty");
			System.exit(-1);
		} else {

			/* only 1 element */
			if (front == rear) {
				value = q[front];
				q[front] = 0;
			} else {
				value = q[front];
				q[front] = 0;
				front = (front + 1) % ASIZE;
			}

		}
		if (front == q.length)
			front = 0;
		return value;
	}

	/* peek function returns the top of the queue */
	public int peek() {
		return q[front];
	}

}
