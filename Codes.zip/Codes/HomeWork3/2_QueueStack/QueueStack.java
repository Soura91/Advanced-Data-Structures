
/*Java Program to implement Queue by using 2 Stacks*/
import java.util.Stack;

public class QueueStack {
	/* two stacks s1 and s2 */
	Stack<Integer> s1;
	Stack<Integer> s2;

	public QueueStack() {
		s1 = new Stack<Integer>();
		s2 = new Stack<Integer>();
	}

	/* push function that pushes the data-- for enqueue */
	public void push(int data) {
		s1.push(data);
	}

	/* pop function returns the data -- for dequeue */
	public int pop() {
		int val;
		if (s1.empty() && s2.empty()) {
			System.out.println("Queue is empty");
			System.exit(0);
		} else {
			if (s2.isEmpty()) {
				while (!s1.empty()) {
					val = s1.pop();
					s2.push(val);
				}
			}
		}
		val = s2.pop();
		return val;
	}

	/* top gives the element at the top of queue */
	public int top() {
		return s2.peek();
	}
}
