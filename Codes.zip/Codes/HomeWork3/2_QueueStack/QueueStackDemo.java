/*Main Function to demonstrate the queue functionality using two stacks*/
public class QueueStackDemo {

	public static void main(String[] args) {
		QueueStack queue = new QueueStack();
		queue.push(1);
		queue.push(2);
		queue.push(3);
		queue.push(4);
		System.out.println(queue.pop());
		System.out.println(queue.top());
		queue.push(5);
		System.out.println(queue.pop());
		System.out.println(queue.top());
		
		
		

	}

}
