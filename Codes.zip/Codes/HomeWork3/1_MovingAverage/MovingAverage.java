
/* Java Program to calculate the Moving Average of Data Stream */
import java.util.LinkedList;
import java.util.Queue;

public class MovingAverage {
	Queue<Integer> q;
	/* Window size */
	int wsize;
	double total;

	/* Constructor MovingAverage */
	public MovingAverage(int ws) {
		q = new LinkedList<>();
		wsize = ws;
	}

	/* next function returns the moving average of data Stream */
	public double next(int m) {
		/* if the size of the queue is less than window size */
		if (q.size() < wsize) {
			total = total + m;
			q.add(m);
			return (total / q.size());
		} else {
			/* if the size of the queue exceeds the window size */
			total = total - q.poll();
			q.add(m);
			total = total + m;
			return (total / wsize);
		}
	}
}
