/* Main Function to Demonstrate the Moving Average from DataStream */

public class MovAverageDemo {
	public static void main(String[] args) {
		/* Creating the object of MovingAverage class of Window size 3 */
		MovingAverage mov = new MovingAverage(3);
		System.out.println("Moving Average of Data Stream 1,10,3,5,2 is ");
		System.out.println(String.format("%.2f", mov.next(1)));
		System.out.println(String.format("%.2f", mov.next(10)));
		System.out.println(String.format("%.2f", mov.next(3)));
		System.out.println(String.format("%.2f", mov.next(5)));
		System.out.println(String.format("%.2f", mov.next(2)));
	}
}
