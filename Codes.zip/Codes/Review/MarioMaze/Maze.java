/* Java program to check if it is possible to pass a maze */
public class Maze {
	/* visited array to check if all the nodes are visited */
	public static boolean[][] visited = { { false, false, false, false, false }, { false, false, false, false, false },
			{ false, false, false, false, false }, { false, false, false, false, false },
			{ false, false, false, false, false } };

	/* checkPathPass function if the mario can pass the maze */
	public static boolean checkPathPass(int[][] m, int row, int col, int life) {
		if ((row < 0) || (row >= 5) || (col < 0) || (col >= 5)) {
			return false;
		}
		if (row == 4 && col == 4)
			return true;
		if (visited[row][col] == true)
			return false;
		visited[row][col] = true;
		if (checkPathPass(m, row + 1, col, life + m[row][col]))
			return true;
		if (checkPathPass(m, row - 1, col, life + m[row][col]))
			return true;
		if (checkPathPass(m, row, col + 1, life + m[row][col]))
			return true;
		if (checkPathPass(m, row, col - 1, life + m[row][col]))
			return true;
		return false;

	}

	/* print matrix prints the matrix */
	public static void print(int[][] ma) {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print(ma[i][j] + "	");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		int[][] maze1 = { { 0, -1, -1, -1, -4 }, { 2, 5, -1, -4, -5 }, { -1, -5, 7, -4, 2 }, { 6, -4, 8, -4, 5 },
				{ 3, 5, 1, -9, 0 } };
		System.out.println("The maze 1 is " );
		print(maze1);
		/* Mario always start at [0,0] and Mario has only has 1 life in the beginning */
		System.out.println(checkPathPass(maze1, 0, 0, 1));

	}
}
