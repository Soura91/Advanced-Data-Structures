
/*Class Node*/
public class Node {
	int data;
	Node next;

	/* Constructor */
	Node(int d) {
		data = d;
		next = null;
	}

	Node() {
	}
}
