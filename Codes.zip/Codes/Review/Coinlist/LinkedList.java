/* Java program to display the gamer’s total life at the end of the game.*/
public class LinkedList {
	Node head;

	/* insert function inserts the new node at the end of the list */
	public LinkedList insert(LinkedList list, int data) {
		Node newnode = new Node(data);
		if (list.head == null) {
			list.head = newnode;
		} else {
			Node temp = list.head;
			while (temp.next != null) {
				temp = temp.next;
			}
			temp.next = newnode;
		}
		return list;
	}
	/*Calculates the gamer’s total life at the end of the game*/
	public static int CalculateCurrentLife(Node coin, Node greenMushroom) {
		int totalife = 3;
		totalife = totalife + (sum(coin)) / 100 + sum(greenMushroom);
		return totalife;
	}

	/* Sum function returns the sum of the list */
	public static int sum(Node ll) {
		int total = ll.data;
		Node temp = ll;
		while (temp.next != null) {
			temp = temp.next;
			total = total + temp.data;
		}
		return total;
	}

	/* printlist function prints the list */
	public void printlist(LinkedList list) {
		Node temp = list.head;
		while (temp != null) {
			System.out.print(temp.data + "-->");
			temp = temp.next;
		}
		System.out.println();
	}

	public static void main(String[] args) {
		LinkedList coin = new LinkedList();
		coin.insert(coin, 10);
		coin.insert(coin, 110);
		coin.insert(coin, 20);
		coin.insert(coin, 50);

		System.out.println("The input coin list  is ");
		coin.printlist(coin);

		LinkedList gm = new LinkedList();
		gm.insert(gm, 0);
		gm.insert(gm, 2);
		gm.insert(gm, 0);
		gm.insert(gm, 1);

		System.out.println("The input greenMushroom list  is ");
		gm.printlist(gm);

		System.out.println("The gamer’s total life at the end of the game is " + CalculateCurrentLife(coin.head, gm.head));

	}
}
