/* java program (using topological sort) to output one possible course sequence,
 *  which allows you to take all the course and also satisfy all the prerequisite requirement
 */

import java.util.*;
public class tsort {
int V;/* No. of vertices*/
    
    /* Adjacency List of each vertex*/
    List <Integer> adj[];
    public tsort(int V)/* Constructor*/
    {
        this.V = V;
       adj = new ArrayList[V];
        for(int i = 0; i < V; i++)
            adj[i]=new ArrayList<Integer>();
    }
    
    /* function to add an edge to graph */
    public void addEdge(int u,int v)
    {
        adj[u].add(v);
    }
    /* prints a Topological Sort of the complete graph */   
    public void topologicalSort(HashMap<Integer, Integer> courses)
    {
        /*in-degree array stores the in-degree of each vertex*/
        int indegree[] = new int[V];      
        for(int i = 0; i < V; i++)
        {
            ArrayList<Integer> temp = (ArrayList<Integer>) adj[i];
            for(int node : temp)
            {
                indegree[node]++;
            }
        }
        
        /* enqueue all vertices with in-degree 0 */
        Queue<Integer> q = new LinkedList<Integer>();
        for(int i = 0;i < V; i++)
        {
            if(indegree[i]==0) 
            	q.add(i);         
        }
        
        /* Initialize count of visited vertices */
        int cnt = 0;
        /* topOrder stores topological ordering of the vertices */   
        ArrayList <Integer> topOrder=new ArrayList<Integer>();
        while(!q.isEmpty())
        {
            /* perform dequeue and add it to topological order */ 
            int u=q.poll();
            topOrder.add(u);
            
            /* Iterate through all its neighboring node of  u and decrease their in-degree by 1 */       
            for(int node : adj[u])
            {
                /* If in-degree becomes zero, add it to queue */
                if(--indegree[node] == 0)
                    q.add(node);
            }
            cnt++;
        }      
        /* Check if there was a cycle */        
        if(cnt != V)
        {
            System.out.println("There exists a cycle in the graph");
            return ;
        }
        
        /* Print topological order */           
        for(int i : topOrder)
        {
            
        	System.out.print(courses.get(i)+ " ");
        }
    }
            

	public static void main(String[] args) {
		/* Hashmap to map courses with vertex 0,1,2,......*/
		HashMap<Integer, Integer> courses = new HashMap<Integer, Integer>();
        courses.put(0, 142);
        courses.put(1, 126);
        courses.put(2, 331);
        courses.put(3, 143);
        courses.put(4, 311);
        courses.put(5, 341);
        courses.put(6, 351);
        courses.put(7, 332);
        courses.put(8, 312);
        courses.put(9, 352);
        courses.put(10, 440);
        courses.put(11, 333);
     
		/* Create a graph given in the above diagram */
		tsort g = new tsort(12); 
        g.addEdge(0, 3); 
        g.addEdge(1, 3); 
        g.addEdge(3, 2); 
        g.addEdge(3, 4); 
        g.addEdge(3, 5); 
        g.addEdge(3, 6);         
        g.addEdge(4, 7); 
        g.addEdge(4, 8); 
        g.addEdge(6, 9); 
        g.addEdge(6, 11); 
        g.addEdge(7, 8);
        g.addEdge(7, 10);
        g.addEdge(7, 11); 
  
        System.out.println("Following is a Topological " + 
                           "sort of the given graph"); 
        g.topologicalSort(courses); 
    } 
}
