/*Java Program to check if the two binary trees are same */

public class SameTree {
	/* isSameTree function checks if the trees are same or not same */
	public static boolean isSameTree(TreeNode tree1, TreeNode tree2) {
		if (tree1 != null && tree2 != null) {
			if (tree1.data != tree2.data) {
				return false;
			} else if (isSameTree(tree1.left, tree2.left)) {
				return isSameTree(tree1.right, tree2.right);
			} else {
				return false;
			}
		} else if (tree1 != null | tree2 != null) {
			return false;
		} else {
			return true;
		}
	}
	/* preorder function prints the tree in pre-order traversal */
	public static void printpreorder(TreeNode p) {
		if (p != null) {
		System.out.print(p.data + "--> ");
		printpreorder(p.left);
		printpreorder(p.right);
	  }
	}

	/* main function */
	public static void main(String[] args) {
		/* constructing two binary trees */
		TreeNode a = new TreeNode(1);
		a.left = new TreeNode(2);
		a.right = new TreeNode(3);
		a.left.left = new TreeNode(4);
		a.left.right = new TreeNode(5);
		a.right.right = new TreeNode(6);

		TreeNode b = new TreeNode(1);
		b.left = new TreeNode(2);
		b.right = new TreeNode(3);
		b.left.left = new TreeNode(4);
		b.left.right = new TreeNode(5);
		b.right.right = new TreeNode(6);
	
		System.out.println("The First binary tree is ");
		printpreorder(a);
		System.out.println("\n The Second binary tree is ");	
		printpreorder(b);	
		
		if (isSameTree(a, b)) {
			System.out.println("\nThe two binary trees are same");
		} else {
			System.out.println("\nThe two binary trees are not same");
		}
	}
}
