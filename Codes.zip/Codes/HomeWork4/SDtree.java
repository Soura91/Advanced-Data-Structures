/* Java program to Serialize and Deserialize Binary Tree */
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class SDtree {
	/* serialize function serializes the tree in the form of String */
	public String serialize(TreeNode root) {
		StringBuffer s = new StringBuffer();
		codeString(root, s);
		return s.toString();

	}

	/* codeString function codes the tree data with '#' and "," */
	private void codeString(TreeNode r, StringBuffer sb) {
		if (r == null) {
			/* "#" is used to code the null node */
			sb.append("#").append(",");
		} else {
			sb.append(r.data).append(",");
			codeString(r.left, sb);
			codeString(r.right, sb);
		}
	}

	/*
	 * deserialize function decodes the String data to build a tree in pre-order
	 * fashion
	 */
	public TreeNode deserialize(String data) {
		/* queue to parse pre-order seralized string */
		Queue<String> nodes = new LinkedList<>(Arrays.asList(data.split(",")));
		return buildTree(nodes);
	}

	/* buildTree function builds the tree */
	private TreeNode buildTree(Queue<String> nodes) {
		String val = nodes.poll();
		if (val.equals("#"))
			return null;
		TreeNode node = new TreeNode(Integer.parseInt(val));
		node.left = buildTree(nodes);
		node.right = buildTree(nodes);
		return node;
	}

	/* pre-order function prints the tree in pre-order traversal */
	public void printpreorder(TreeNode p) {
		if (p != null) {
		System.out.print(p.data + "--> ");
		printpreorder(p.left);
		printpreorder(p.right);
	  }
	}

	/* main function */
	public static void main(String[] args) {
		/* constructing two binary trees */
		TreeNode a = new TreeNode(1);
		a.left = new TreeNode(2);
		a.right = new TreeNode(3);
		a.right.left = new TreeNode(4);
		a.right.right = new TreeNode(5);
		SDtree sd = new SDtree();
		String s = sd.serialize(a);
		System.out.println("The Serialized data is " + s);
		TreeNode b = sd.deserialize(s);
		System.out.println("The preorder traversal of tree after deserializing the data is ");
		sd.printpreorder(b);

	}

}
