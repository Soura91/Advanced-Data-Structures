
/* Class TreeNode */
public class TreeNode {
	int data;
	TreeNode left, right;

	TreeNode(int d) {
		data = d;
		left = null;
		right = null;
	}

}
