/* Java program to invert the given binary tree*/
public class InvertTree {
	/* InvertTree function inverts the binary tree */
	public static TreeNode InvTree(TreeNode root) {
		if (root == null) {
			return null;
		}
		TreeNode temp = root.left;
		root.left = InvTree(root.right);
		root.right = InvTree(temp);
		return root;
	}

	/* printInorder function prints the tree in In-order traversal */
	public static void printInorder(TreeNode p) {
		if (p != null) {
		printInorder(p.left);
		System.out.print(p.data + "--> ");
		printInorder(p.right);
	   }
	}

	/* main function */
	public static void main(String[] args) {
		/* constructing two binary trees */
		TreeNode a = new TreeNode(1);
		a.left = new TreeNode(2);
		a.right = new TreeNode(3);
		a.left.left = new TreeNode(4);
		a.left.right = new TreeNode(5);
		a.right.left = new TreeNode(6);
		a.right.right = new TreeNode(7);
		System.out.println("The In-order traversal of  Binary Tree  is ");
		printInorder(a);
		InvTree(a);
		System.out.println("\nThe Inverted Binary Tree is ");
		printInorder(a);

	}

}
