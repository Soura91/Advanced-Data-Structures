/* main function to demonstrate the tries */
public class TrieDemo {

	public static void main(String[] args) {
		Trie t = new Trie();
		t.insert("SiChen");
		System.out.println(t.search("Chen"));
		System.out.println(t.startsWith("Si"));
		System.out.println(t.startsWith("SiCui"));
		t.insert("SiCui");
		System.out.println(t.search("SiChen"));
		System.out.println(t.startsWith("SiCu"));

	}

}
