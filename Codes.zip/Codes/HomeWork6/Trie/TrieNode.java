/* Trie Node Class*/
import java.util.HashMap;

public class TrieNode {
	boolean isEnd;
    HashMap<Character, TrieNode> children;
    public TrieNode() {
        this.isEnd = false;
        this.children = new HashMap<>();
    }
}
