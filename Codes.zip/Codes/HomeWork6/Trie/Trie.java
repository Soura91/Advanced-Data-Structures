/* class Trie */
public class Trie {
	TrieNode root;

	/** Constructor */
	public Trie() {
		root = new TrieNode();
	}

	/** Inserts a string into the trie. */
	public void insert(String str) {
		TrieNode cur = root;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (!cur.children.containsKey(ch)) {
				/*
				 * create a new node if the character is not present in the hashmap of children
				 */
				cur.children.put(ch, new TrieNode());
			}
			cur = cur.children.get(ch);
		}
		/* Setting the given root node to true after inserting */
		cur.isEnd = true;
	}

	/** Returns if the string is in the trie. */
	public boolean search(String str) {
		TrieNode cur = root;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (!cur.children.containsKey(ch)) {
				return false;
			}
			cur = cur.children.get(ch);
		}
		/* return true only if the reached node represents a word */
		return cur.isEnd;
	}

	/**
	 * Returns if there is any word in the trie that starts with the given prefix.
	 */
	public boolean startsWith(String prefix) {
		TrieNode cur = root;
		for (int i = 0; i < prefix.length(); i++) {
			char ch = prefix.charAt(i);
			if (!cur.children.containsKey(ch)) {
				return false;
			}
			cur = cur.children.get(ch);
		}
		return true;
	}
}
