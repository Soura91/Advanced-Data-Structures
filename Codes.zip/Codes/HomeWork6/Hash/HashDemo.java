
/*Java program to demonstrate the hash function*/
import java.util.Scanner;

public class HashDemo {
	/* hashcode function returns the hashvalue of the given key */
	public static int hashcode(String s, int hs) {
		if (s.length() == 0) {
			return 0;
		} else {
			int hash = 0;
			int p = s.length() - 1;
			for (int i = 0; i < s.length(); i++) {
				/* extracting character from the string s */
				int c = (int) (s.charAt(i));
				hash = (int) (hash + Math.pow(33, (p)) * c);
				p--;
			}
			return (hash % hs);
		}
	}

	/* main function */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the string");
		String s = input.nextLine();
		System.out.println("Enter the size of the hash table");
		int hs = input.nextInt();
		int hash = hashcode(s, hs);
		System.out.println("Hash value of the key " + s + " is " + hash);
		input.close();
	}

}
