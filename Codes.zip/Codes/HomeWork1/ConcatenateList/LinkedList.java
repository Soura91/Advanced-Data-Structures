/*Class LinkedList*/
public class LinkedList {
	Node head; /* head of the list */
	/* Function to concatenate two lists */

	public Node concatenate(Node l1, Node l2) {
		/* Checking null value */
		if (l1 == null) {
			return l2;
		}
		if (l2 == null) {
			return l1;
		}
		/* traversing the list l1 */
		while (l1.next != null) {
			l1 = l1.next;
		}
		Node temp = l1;
		while (l2 != null) {
			/* creating the new node and copying the data from list l2 */
			temp.next = new Node(l2.data);
			temp = temp.next;
			l2 = l2.next;
		}
		return l1;
	}

	/* This function inserts new node at the front of the linkedlist */
	/* This function is used to create lists l1 and l2 */
	public void insert(int new_data) {
		Node new_node = new Node(new_data);

		if (head == null) {
			head = new Node(new_data);
			return;
		}
		new_node.next = null;
		Node prev = head;
		while (prev.next != null)
			prev = prev.next;
		prev.next = new_node;
		return;
	}

	/* printlist prints the list */
	public void printlist() {
		Node n = head;
		while (n != null) {
			System.out.print("->" + n.data);
			n = n.next;
		}
		System.out.println();
	}
}
