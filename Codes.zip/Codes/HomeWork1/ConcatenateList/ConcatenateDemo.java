import java.util.Scanner;

/*Java Program to Concatenate two lists*/
public class ConcatenateDemo {

	public static void main(String[] args) {
		LinkedList l1 = new LinkedList();
		LinkedList l2 = new LinkedList();
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the size of the list l1 you want to create");
		int l1size = input.nextInt();
		System.out.println("Enter the inputs of the the list l1");
		for (int i = 0; i < l1size; i++) {
			int n = input.nextInt();
			l1.insert(n);
		}
		System.out.println("Enter the size of the list l2 you want to create");
		int l2size = input.nextInt();
		System.out.println("Enter the inputs of the the list l2");
		for (int j = 0; j < l2size; j++) {
			int m = input.nextInt();
			l2.insert(m);
		}

		System.out.println("The list l1 is ");
		l1.printlist();

		System.out.println("The list l2 is ");
		l2.printlist();
		/* Calling function Concatenate */
		l1.concatenate(l1.head, l2.head);

		System.out.println("After Concatenation of lists l1 and l2");

		System.out.println("The list l1 is ");
		l1.printlist();

		System.out.println("The list l2 is ");
		l2.printlist();
		input.close();
	}

}
