import java.util.Scanner;

public class InsertNodeDemo {

	public static void main(String[] args) {
		LinkedList l1 = new LinkedList();
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the size of the list you want to create");
		int l1size = input.nextInt();
		System.out.println("Enter the inputs of the the list");
		for (int i = 0; i < l1size; i++) {
			int n = input.nextInt();
			l1.insert(n);
		}
		System.out.println("The list l1 is ");
		l1.printlist();
		System.out.println("The size of the list l1 is " + l1.size());
		System.out.println("Enter the position  to insert the node ");
		int pos = input.nextInt();
		while (pos > l1.size() + 1) {
			System.out.println("The position which you are inserting exceeds the size the of the list");
			System.out.println("Enter the correct postion");
			pos = input.nextInt();
		}

		System.out.println("Enter the value to insert the node ");
		int val = input.nextInt();
		/* Adding new node */
		Node newnode = new Node(val);
		/* Inserting new node at the specified position */
		l1.insertNode(newnode, pos);
		System.out.println("After inserting the node , list l1 is ");
		l1.printlist();
		System.out.println("The size of the list l1 is " + l1.size());
		input.close();
	}

}
