/*Class LinkedList*/
public class LinkedList {
	Node head; /* head of the list */

	/* This function inserts new node at the specified position of the linkedlist */
	public Node insertNode(Node n, int position) {

		if (head == null) {
			return n;
		}
		if (position == 1) {
			n.next = head;
			head = n;
			return head;
		}
      Node temp = new Node();
		temp.next = head;
		Node current = temp;
		for (int i = 1; i < position; ++i) {
			current = current.next;
		}
		n.next = current.next;
		current.next = n;
		return temp.next;
	}

	/* Returns size of the linked list */
	public int size() {
		Node temp = head;
		int count = 0;
		while (temp != null) {
			count++;
			temp = temp.next;
		}
		return count;
	}

	/* This function inserts new node at the front of the linkedlist */
	public void insert(int new_data) {
		Node new_node = new Node(new_data);

		if (head == null) {
			head = new Node(new_data);
			return;
		}

		new_node.next = null;
		Node prev = head;
		while (prev.next != null)
			prev = prev.next;
		prev.next = new_node;
		return;
	}

	/* printlist prints the list */
	public void printlist() {
		Node n = head;
		while (n != null) {
			System.out.print("->" + n.data);
			n = n.next;
		}
		System.out.println();
	}
}
